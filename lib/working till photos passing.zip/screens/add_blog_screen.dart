import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:my_blog_app/models/blog.dart';
import 'package:my_blog_app/utils/db_helper.dart';

class AddBlogScreen extends StatefulWidget {
  @override
  _AddBlogScreenState createState() => _AddBlogScreenState();
}

class _AddBlogScreenState extends State<AddBlogScreen> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _authorController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _tagsController = TextEditingController();
  File? _imageFile;
  final picker = ImagePicker();

  Future getImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _imageFile = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  Future<void> _saveBlog() async {
    final String title = _titleController.text;
    final String description = _descriptionController.text;
    final String author = _authorController.text;
    final String date = _dateController.text;
    final String tags = _tagsController.text;

    // Check if any field is empty before saving
    if (title.isEmpty ||
        description.isEmpty ||
        author.isEmpty ||
        date.isEmpty ||
        tags.isEmpty) {
      // Show an error message or dialog to inform the user to fill all fields
      return;
    }

    final String imagePath =
        _imageFile?.path ?? ''; // Provide a default value if _imageFile is null
    final Blog newBlog = Blog(
      title: title,
      description: description,
      author: author,
      date: date,
      tags: tags.split(','),
      imagePath: imagePath,
    );

    await DatabaseHelper.instance.insertBlog(newBlog);

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Blog'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _titleController,
                decoration: InputDecoration(labelText: 'Title'),
              ),
              SizedBox(height: 12.0),
              TextField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Description'),
                maxLines: null, // Allows for multiline input
              ),
              SizedBox(height: 12.0),
              _imageFile != null
                  ? Image.file(
                      _imageFile!,
                      height: 200,
                    )
                  : Placeholder(
                      fallbackHeight: 200,
                    ),
              SizedBox(height: 12.0),
              Center(
                child: ElevatedButton(
                  onPressed: getImage,
                  child: Text('Select Image'),
                ),
              ),
              SizedBox(height: 12.0),
              TextField(
                controller: _authorController,
                decoration: InputDecoration(labelText: 'Author'),
              ),
              SizedBox(height: 12.0),
              TextField(
                controller: _dateController,
                decoration: InputDecoration(labelText: 'Date'),
                keyboardType: TextInputType.datetime,
              ),
              SizedBox(height: 12.0),
              TextField(
                controller: _tagsController,
                decoration:
                    InputDecoration(labelText: 'Tags (comma-separated)'),
              ),
              SizedBox(height: 24.0),
              ElevatedButton(
                onPressed: _saveBlog,
                child: Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
