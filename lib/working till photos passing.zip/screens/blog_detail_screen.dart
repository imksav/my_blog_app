import 'dart:io';

import 'package:flutter/material.dart';
import 'package:my_blog_app/models/blog.dart';

class BlogDetailScreen extends StatelessWidget {
  final Blog blog;

  BlogDetailScreen({required this.blog});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Blog Detail'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              blog.title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 24.0,
              ),
            ),
            SizedBox(height: 8.0),
            Text(
              blog.description,
              style: TextStyle(fontSize: 16.0),
            ),
            SizedBox(height: 16.0),
            Text('Author: ${blog.author}'),
            SizedBox(height: 8.0),
            Text('Date: ${blog.date}'),
            SizedBox(height: 8.0),
            if (blog.imagePath != null &&
                blog.imagePath!
                    .isNotEmpty) // Add condition to check if imagePath is not null or empty
              Image.file(
                File(blog.imagePath!),
                height: 200,
              ),
          ],
        ),
      ),
    );
  }
}
