class Blog {
  final int? id;
  final String title;
  final String description;
  final String author;
  final String date;
  final List<String> tags;
  final String? imagePath;

  Blog({
    this.id,
    required this.title,
    required this.description,
    required this.author,
    required this.date,
    required this.tags,
    this.imagePath, // No need for imagePath to be required
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'author': author,
      'date': date,
      'tags': tags.join(','),
      'imagePath':
          imagePath ?? '', // Provide a default value if imagePath is null
    };
  }

  factory Blog.fromMap(Map<String, dynamic> map) {
    return Blog(
      id: map['id'],
      title: map['title'],
      description: map['description'],
      author: map['author'],
      date: map['date'],
      tags: (map['tags'] as String).split(','),
      imagePath: map['imagePath'],
    );
  }
}
