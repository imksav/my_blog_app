import 'package:flutter/material.dart';
import 'package:my_blog_app/screens/home_screen.dart';
import 'package:my_blog_app/utils/db_helper.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await DBHelper.initDatabase();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Blog App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomeScreen(),
    );
  }
}
